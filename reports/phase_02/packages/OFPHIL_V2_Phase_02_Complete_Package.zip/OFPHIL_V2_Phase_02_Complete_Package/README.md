# OFPHIL V2 — Phase 02 Data Preparation Package

- **Authoritative Source:** `data/processed/charity-patient-realism-revised.csv`
- **Execution Status:** All 6 notebooks cleared of stale outputs and marked `PENDING MANUAL EXECUTION` (`01` -> `06`).
