# Ground Truth OCR Transcription Verification Report (100% Complete)

**Document Source:** [`ocr_transcription_annotations.csv`](file:///c:/Users/ASUS%20TUF/Desktop/Project%20in%20Program/Thesis%20Project/dss-charity-eligibity-classification/data/interim/document_processing/ground_truth_annotations/ocr_transcription_annotations.csv)  
**Detailed Summary CSV:** [`blank_transcriptions_summary.csv`](file:///c:/Users/ASUS%20TUF/Desktop/Project%20in%20Program/Thesis%20Project/dss-charity-eligibity-classification/data/interim/document_processing/blank_transcriptions_summary.csv)  
**Status Date:** November 6, 2026  

---

## 📊 Final Dataset Statistics

* **Total Annotations:** `25,885` rows
* **With Ground Truth:** `25,885` rows (**100.00% complete**) ✅
* **Blank Entries:** **`0` rows (0.00%)** 🎉

---

## 🏷️ Standardized Visual & Unfilled Tags Applied

| Tag | Count | Description / Use Case |
| :--- | :---: | :--- |
| **`[SIGNATURE]`** | `1,968` | Lahat ng pirma ng doktor (`doctor_signature`) at signatory entries. |
| **`[NONE]`** | `297` | Lahat ng blangkong form fields at empty family table cells (e.g. walang sariling kita ang mga bata/dependent). |
| **`[PICTURE]`** | `9` | Visual photos ng bahay at pasyente (`picture_of_the_house` / `picture`). |
| **`[SEAL]`** | `164` | Opisyal na dry seals at institutional stamps. |
| **`[CHECKMARK]`** | `82` | Checked checkboxes at tick boxes sa intake forms. |

---

## 💾 Backup Reference
* Bago isinagawa ang encoding ng Option 1, nai-save ang backup sa:  
  [`data/interim/document_processing/ground_truth_annotations/backups/ocr_transcription_annotations_backup_before_option1_fill.csv`](file:///c:/Users/ASUS%20TUF/Desktop/Project%20in%20Program/Thesis%20Project/dss-charity-eligibity-classification/data/interim/document_processing/ground_truth_annotations/backups/ocr_transcription_annotations_backup_before_option1_fill.csv)
